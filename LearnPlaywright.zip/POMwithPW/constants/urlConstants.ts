export enum URLConstants {
    baseUrl='http://leaftaps.com/opentaps/control/main',
    homeUrl='http://leaftaps.com/opentaps/control/login'
}