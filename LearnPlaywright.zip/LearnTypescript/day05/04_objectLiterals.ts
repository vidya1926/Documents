//object literals

let userData:{
  name:string;
  id:number|string;
  emailId:string
} ={
    name:"saritha",
    id:123,
    emailId:"saritha@123"
};

console.log(userData)
//Dot notation
console.log(userData.id)

//bracket notation
console.log(userData["name"])




