//type alias  -custom datatype
//type variableName=typeofdata

type dimension={
    height:number,
    width:number
    shapeName:string
}

let shape:dimension={height:10,width:25,shapeName:"Square"}

type id=number;

let userId:id=123

//union and intersection

//union type -->assign multiple datatype to the variable

