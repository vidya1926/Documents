let fname="Jeyapriya";

let uname;
 uname="Vidya";
 uname=123446
 console.log(uname)
//type  variablename:typeOfvarible =value
//static typing 
let username:string;
username="123";
console.log(username)

let browserVersion:number=121.45
let isbrowserOpen:boolean=true;
//let arr={'',''}

//literal dec
let testType:string[]=["Regression","sanity"]

//object
let testData:Array<string>=["Username","password"]
testData.push("email") //add data into the last oindex of the array
console.log(testData)

 //type inference 

   //implicit inference 
   let lastname="Vlaue"
   console.log(typeof lastname)
   //explicit inference
   let lname:string="Value"

   let browser:any[]=["chrome",121.4519,true]