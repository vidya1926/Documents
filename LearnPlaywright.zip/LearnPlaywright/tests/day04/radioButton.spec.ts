import test from "@playwright/test";

test(`Radio Button`,async({page})=>{
    await page.goto("https://www.w3schools.com/jquery/tryit.asp?filename=tryjquery_sel_checked");   
   const fr= page.frameLocator("//iframe[@id='iframeResult']").first();
   const s=fr.locator("//input[@value='Car']")

const preCheck=await s.isChecked()   
console.log(preCheck)
await s.click();
const postCheck=await s.isChecked()
  
    console.log(postCheck)
})
   