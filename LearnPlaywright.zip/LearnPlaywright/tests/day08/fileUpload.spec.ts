import test, { expect } from '@playwright/test'
import { on } from 'events'
import path from 'path'

test("File to Upload",async({page})=>{
    await page.goto("https://www.leafground.com/file.xhtml")

    //upload element with attribute in dom asa type= file
    
  //const  filePath="./dataToUpload";

   // await page.setInputFiles("input[type='file']",["./dataToupload/Cheatsheet.txt"]);   
   
   await page.locator(".card").filter({hasText:"Basic Upload"})
   .locator("input[type='file']").setInputFiles(path.join(__dirname,"Cheatsheet.txt"))
   
   await expect(page.locator("[class='ui-fileupload-filename']")).toContainText("Cheatsheet.txt")
    await page.waitForTimeout(3000);
  
})



