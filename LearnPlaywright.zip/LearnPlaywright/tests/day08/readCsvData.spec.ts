
import test from '@playwright/test'

import * as path from 'path';

import { excelData } from "../day12/readExcel";

let formData: any[];

test(`Read data using excel file `, async ({ page }) => {

        await page.goto("http://leaftaps.com/opentaps/control/main")
        await page.locator("#username").fill("DemoCsr");
        page.fill("#password", "crmsfa");
        await page.locator(".decorativeSubmit").click();
        await page.getByText("CRM/SFA", { exact: true }).click()
        await page.getByText("Leads", { exact: true }).click()
    
      
        formData=  excelData('./data/createLead.xlsx')
      
        for (const data of formData) {
                console.log(data)
                await page.fill("#createLeadForm_companyName", data.Cname)
                await page.fill("#createLeadForm_firstName", data.Fname)
                await page.fill("#createLeadForm_lastName", data.lnmae)
                await page.click(".smallSubmit");
        }
})