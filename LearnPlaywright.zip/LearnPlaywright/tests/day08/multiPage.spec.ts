import test from "@playwright/test";



test("Learn to handle pages", async ({ page, context }) => {
   
    await page.goto("https://www.leafground.com/window.xhtml")
    
    //create a promise -->handle all the opened windows
    //action which trigggers the event 
    //resolve the promise

    async function focusWindow(locator:string){
        const newPage = context.waitForEvent('page');
        await page.locator(locator).click()
        const newWindow=await newPage;    
        await newWindow.waitForLoadState('load')        
        return await newWindow.title();
     }

   const open="//span[text()='Open']"
   const windoeName=await focusWindow(open)
   console.log(windoeName)

})
