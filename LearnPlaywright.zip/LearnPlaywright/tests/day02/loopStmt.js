
// //to write for loop 
// //syntax --> for(starting point, range of values, incrementing){}
// // startpoint ->where the execution with the input value 
// // range -->10-->15 -->range (end point)
// // increment  -->10 +1  -->11

// // for(let input=10;input<=15; input++){
// //     console.log(2*input)
// //     //  input++ -input =input+1 -->10 -->11
// // }

// // let imhealthy=true
// // for(let round=1;round<=10;round++){
// //     if(!imhealthy && round>2 ){
// //         break;
// //     }
// //     console.log(round)

// // }


// //while loop

// //while(true){
// //click on next button
// //}


// let itsRaining=true

// // while(!itsRaining){
// //     console.log("Go for walking")
// // }

// //do while
// do{
// console.log("Keep walking")
// }while(!itsRaining)


// function jogging(){
//     let imhealthy=true
//  for(let round=1;round<=10;round++){
//     if(!imhealthy && round>2 ){
//         break;
//      }
//      console.log(round)

//  }
// }

// jogging();


for(let i=20;i>=10;i--){
  console.log(i);
}
