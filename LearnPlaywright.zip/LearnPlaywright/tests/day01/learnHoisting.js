

console.log(username);
var username="Vidya";
console.log(username);


// var username;
// console.log(username)
// username="vidya"

// console.log(password)
// let password="vid123"

const pwd=123;  
//const pwd=345;
pwd=310;  //runtime exception ->Assignment to constant variable.