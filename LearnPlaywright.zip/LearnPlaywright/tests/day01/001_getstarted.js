import faker from '@faker-js/faker'
 //comment line

// /*
// multiple lines to comment
// */

// //print the statement
// //run the script --> node filename.js
// console.log('Welcome to playwright Js training session')

// //declare the information using js
// //no specification/keyword to define the type of information


// /*
// string  -"Name",'Session',`priceValue` -backtick
// number -124, 12.5, 89032904024
// boolean- true false
// undefined
// null
// */


// var username="DemoSalesmanager"
// console.log(username)
// console.log(typeof username)

// var pwd=1234;
// console.log(pwd)
// console.log(typeof pwd)

// var isInstalled=true
// console.log(isInstalled)
// console.log(typeof isInstalled)

// var credentials;
// console.log(credentials)
// console.log(typeof credentials)

// //not recommended
// var firstname=null
// console.log(firstname)
// console.log(typeof firstname)


// username="DemoSales" //re assignment -->replacing the existing value

// var username=1234; //re declaration -->should not right 

// //let is the keyword used to declare a variable
// //allow you to reassign the value
// //will no allow you to redeclare it

// //difference between var and let 

// let firstName="vidya"
// //let firstName="R"  not allowed to redeclare
const date=  faker.date.past().getDate()
      
console.log(date)



 
function getQualification(){
    const qualification = {
        degree: faker.helpers.arrayElement(['Bachelor', 'Master', 'PhD', 'Certificate', 'Diploma']),
        fieldOfStudy: faker.helpers.arrayElement(['Computer Science', 'Engineering', 'Business', 'Arts', 'Science']),
        institution: faker.company.name(),
        graduationDate: faker.date.past(10).toLocaleDateString(),
        grade: faker.helpers.arrayElement(['A', 'B', 'C', 'D', 'E']),
      };

      return qualification;
      
}

console.log(getQualification())