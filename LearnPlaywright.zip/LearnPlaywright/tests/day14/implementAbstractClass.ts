import MyReporter from "../day16/learnCustomReports"
import { TestReport } from "./learnAbstractClass"

class SalesReport extends MyReporter{
    generateReport(): void {
       console.log("Generating allure Report")
    }

    takeScreenshot(): void {
        console.log("")
    }
    
}

