import { CusBrowser } from "./learnInterface";

class Salesforce implements CusBrowser{
    reportName: string;
    launchBrowser(): void {
       
    }
    fillAndEnter(): void {
       
    }
    clickAndverifyTitle(): string {
        return ""
    }
    startReport(): void {
        
    }
    
}