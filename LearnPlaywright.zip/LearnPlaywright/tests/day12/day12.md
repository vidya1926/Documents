Today's agenda:

9.00AM to 10.00AM - Recap & remaining Test Annotation
10.00AM to 10.30AM -Custom Fixture
10.30AM to 10.45AM -Break
10.45AM to 11.00AM -classroom
11.00AM to 11.30AM -Keyboard and Mouse actions
11.30AM to 12.00PM -Trace viewer
12.00PM to 12.40PM -CodeGen
12.40PM to 1.00PM - GeoLocation/Device Emulation

oops
pom
framework

reporting-custom report /allure
ci integration-github action
jira integration
network interception
console log
visual testing
shadow dom

To declare the pre and post conditions

test.beforeAll -->suite level exceution  ->executes once with all test  -->db config
test.beforeEach  ->exe before each and every test -->precondition -->loading url
  test  ->test
  test-->
test.aferEach -->exe after each and every test  ->close browser/context/assert
test.afterAll   -->suite level exe -->once all test is completed , afterall will be executed ->closing db



  
custom fixture -->creating new function with predefined logic

page -->Page --> context.newPage()


type
ctrl click
enter
tab

hover 
dbclick
right
scroll
drag anddrop
up and down



codegen -->record and playback
generate the test steps 












https://forms.office.com/r/MzRYbx6xnE