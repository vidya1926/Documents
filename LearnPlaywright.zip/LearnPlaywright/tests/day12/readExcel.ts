import xlsx from 'xlsx';
 const excelData=(filePath:string) :any[]=>{
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0]; // Get the first sheet
    const sheet = workbook.Sheets[sheetName];
    return xlsx.utils.sheet_to_json(sheet);
  }
  export {excelData}

 