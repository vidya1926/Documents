import { SFHome } from "./sfhomePage";


class SFLeadsPage extends SFHome{



    
}