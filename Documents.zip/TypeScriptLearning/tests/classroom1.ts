class ShoppingCart {

    public addItem(){
        console.log("Item added to the cart.");
    }

    private removeItem():string{
        
        return "Removed the item"
    }

    public checkout(accountName: string, cardNumber: string): void {
        console.log(`Checkout initiated for ${accountName} with card number ${cardNumber}.`);
    }
}

// Create an instance of the ShoppingCart class
const myShoppingCart = new ShoppingCart();

// Call methods on the instance
myShoppingCart.addItem();
myShoppingCart.checkout("Vidya", "1234-5678-9012-3456");


//function overloading

function calculateArea(shape:'rectangle', length:number, width?:number):void;
function calculateArea(shape:'circle', radius:number):void;

function calculateArea(shape:string, length:number) {
console.log(`Calculate area for ${shape} is `+length);
}



