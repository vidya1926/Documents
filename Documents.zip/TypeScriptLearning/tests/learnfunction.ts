
class LoginPage{


browserName: string;
browserVersion: number;
url: string;


constructor(bName:string, bVersion:number, URL: string){


this.browserName = bName;
this.browserVersion = bVersion;
this.url = URL;
console.log(`The browser details are: ${bName}, ${bVersion}, ${URL}`);

}


signUp (username:string, password: string):string{

return username+ " "+password;
}
}
const myBrowser = new LoginPage("chrome", 117, "http://leaftaps.com/opentaps/control/main");
const cred = myBrowser.signUp("Demosalesmanager", "crmsfa");
console.log(`The credentials are: ${cred}`);

