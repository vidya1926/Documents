import{Browser,PaymentDetails} from "./interface_01"

class Dmart implements Browser,PaymentDetails{
    payCOD(): void {
        console.log("Payment done through COD");
    }
    payCard(): number {
        console.log("Payment through debitcard");
        return 123456739;
    }


    browserName: string ="Chrome";
   
   
    getBrowserVersion(): string {
       return this.browserName;
    }
    getStatus(): boolean {
      return true;
    }
  
}

const buyPdts= new Dmart();
console.log(buyPdts.getBrowserVersion());

console.log(buyPdts.getStatus())
buyPdts.payCOD();
console.log(buyPdts.payCard());