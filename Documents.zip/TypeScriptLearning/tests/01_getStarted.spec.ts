import { chromium ,test} from "@playwright/test"

test("My first code", async() => {

         const browserInstance=  await chromium.launch({headless:false,channel:"chrome"});
         const context= await browserInstance.newContext();
         const page =await context.newPage();

         await page.goto("https://www.google.com");

         await page.locator('[name=q]').fill("TypeScript tutorial");

        const title=await page.title();
        console.log(title);



})
