"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Dmart = /** @class */ (function () {
    function Dmart() {
        this.browserName = "Chrome";
    }
    Dmart.prototype.payCOD = function () {
        console.log("Payment done through COD");
    };
    Dmart.prototype.payCard = function () {
        console.log("Payment through debitcard");
        return 123456739;
    };
    Dmart.prototype.getBrowserVersion = function () {
        return this.browserName;
    };
    Dmart.prototype.getStatus = function () {
        return true;
    };
    return Dmart;
}());
var buyPdts = new Dmart();
console.log(buyPdts.getBrowserVersion());
console.log(buyPdts.getStatus());
buyPdts.payCOD();
console.log(buyPdts.payCard());
