/*
Classroom (Window Handles)
1) Open Salesforce Login Page https://login.salesforce.com
2) Enter the username.
3) Enter the password.
4) Click Login.
5) Click 'Learn More' inside Mobile Publisher section.
6) It will open a new window of "Confirm Redirect".
7) Click Confirm.
8) Print the title of the child window (Confirm Redirect).
*/
 
import { expect, test } from "@playwright/test";
 
test("Learning Window Handles", async ({ context, page }) => {
 
    
    await page.goto("https://login.salesforce.com");
    await page.fill("#username", 'radhakrishnan@testleaf.com');
    await page.fill("#password", 'Chennai@123')
    await page.click("#Login");
 
    const windowPromise = context.waitForEvent("page");
 

    await page.getByTitle('Learn More').click();
 
       const window = await windowPromise;
 
    await window.bringToFront();
 
    window.getByRole('button', {name: 'Confirm'}).click();
 
    await window.waitForLoadState('load');
    const titleText = await window.title();
 
    console.log(`Title of the page : ${titleText}`);
    // expect(titleText).toContain("Create and Publish Custom-Branded Mobile Apps - Salesforce.com");
})
