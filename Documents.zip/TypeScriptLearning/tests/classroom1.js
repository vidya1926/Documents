var ShoppingCart = /** @class */ (function () {
    function ShoppingCart() {
    }
    
    ShoppingCart.prototype.addItem = function () {
        console.log("Item added to the cart.");
    };
    ShoppingCart.prototype.removeItem = function () {
        console.log("Item removed from the cart.");
    };
    ShoppingCart.prototype.checkout = function (accountName, cardNumber) {
        console.log("Checkout initiated for ".concat(accountName, " with card number ").concat(cardNumber, "."));
    };
    return ShoppingCart;
}());
// Create an instance of the ShoppingCart class
var myShoppingCart = new ShoppingCart();
// Call methods on the instance
myShoppingCart.addItem();
myShoppingCart.checkout("Vidya", "1234-5678-9012-3456");
