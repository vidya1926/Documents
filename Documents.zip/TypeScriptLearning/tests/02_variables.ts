import { syncBuiltinESMExports } from "module";

let x="vidya";
console.log(x);


let comName: string  
comName="Testleaf";

console.log(comName);

let age: number;
age=34;

console.log(`my age is ${age}`)

let names: string[]= ['vidya','Sanjay','Aksaj'];
console.log(names);
console.log("Learning TS variables");

let empDetails:{name: string;age: number;isNw:boolean}={
    name:'Renu',
    age:36,
    isNw:false,

    };

    let emp:{name: string;age: number;isNw:boolean}[]=[

        {name:"Renu",age:25, isNw:false},
        {name:"vidya",age:35, isNw:false},
    ]
       console.log(emp);
        
    type supportedBrowser="chrome"|"Firefox"


    function getBrowser(browserName:supportedBrowser){
        if(browserName==="chrome"){
            console.log("Launching chrome")
        }
        else{
            console.log("Launch firefox")
        }

        getBrowser("chrome")

    }
