var x = "vidya";
console.log(x);
var comName;
comName = "Testleaf";
console.log(comName);
var age;
age = 34;
console.log("my age is ".concat(age));
var names = ['vidya', 'Sanjay', 'Aksaj'];
console.log(names);
console.log("Learning TS variables");
var empDetails = {
    name: 'Renu',
    age: 36,
    isNw: false,
};
var emp = [
    { name: "Renu", age: 25, isNw: false },
    { name: "vidya", age: 35, isNw: false },
];
console.log(emp);
