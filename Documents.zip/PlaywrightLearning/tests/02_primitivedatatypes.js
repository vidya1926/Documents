console.log("Welcome to javascript");
/*
string here is a primitive datatype
number-includes all types int short long decimal
boolean
undefined
null
*/
var name="Vidyabhaathi";
console.log(typeof name);
var age =37;
console.log(typeof age);
var ht=5.4;
console.log(typeof ht);
var hadLunch=true;
console.log(typeof hadLunch);
var phonenumber;
console.log(typeof phonenumber);
phonenumber=97492027823;
console.log(typeof phonenumber);