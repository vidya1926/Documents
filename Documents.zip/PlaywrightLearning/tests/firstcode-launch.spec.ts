import { chromium, test } from "@playwright/test";

test("To launch a browser", async () => {

const browserInstance = await chromium.launch({ headless: false, channel:
"chrome" });

const browserContext = await browserInstance.newContext();

const page = await browserContext.newPage();
await page. goto ("https://login.salesforce.com/"); // const userName=page.locator ("#username");
 const userName=page.getByLabel ("Username");
const password=page.locator ("#password");
 const submit=page.locator ("#Login");
await userName.fill("vidyar@testleaf.com"); await password. fill ("Force@123");
await submit.click();
 await page.waitForLoadState('load');
console.log(await page.title());


});