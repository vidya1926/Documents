
//global variables
var firstname="vidya";
console.log(firstname);

var firstname="vidya bharathi";
console.log(firstname)

let firstName="Sanjay"; //let wil not allow to create same variable name
let lastname="AV";

//Function 
let gender="female";
let color="blue";
print(gender);

//let color="blue";
function print(gender){
    var age=25;// function  scope variable 
    if(gender.startsWith("female")){      
      //if(gender==="female")
        console.log("she");
    }else{
        console.log("He");
    }
    console.log(age);
    console.log(color);
}

const accNumber=123456;
//accNumber=12340948494;
console.log(accNumber);

