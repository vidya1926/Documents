
let browserName='chrome';

let browser=new String("chrome");

console.log(browser.charAt(4));
console.log(browserName.charAt(0));


let productName= "L'oreal"; //this is allowed
console.log(productName);

//let product= 'L'oreal';  not allowed
let product='L\'oreal'; //use escape character \ to escape from the following character
console.log(product);


let quotes="I am learning \"\"";  //before each character we need to us \
console.log(quotes);

//concatenation

let name="vidya";

let phno="8948493030";
const rsult= name+" with phno "+phno
console.log(rsult);

//back tick ES6 -2015 are used to concatenate with dynamic value into the string

let output =`The phone number is ${phno} `
console.log(output);

//length is a property
console.log(output.length);
