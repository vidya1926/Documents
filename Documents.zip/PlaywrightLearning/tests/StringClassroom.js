
let  fname="vidya";

var chars =fname.split("");
console.log(typeof chars);



for(let n=fname.length;n>=0;n--){
        var reversedalue=fname.charAt(n);
}

const str = "vidya";
let reversedStr = "";

for (let i = str.length - 1; i >= 0; i--) {
	reversedStr += str[i];
}
console.log(reversedStr);
