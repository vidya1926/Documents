var val=10;
console.log(val++);
console.log(++val);

console.log(1==1);
console.log(1==="1"); //strict equals or triple equals compares the datatype as well as the value and return true if matches
console.log("vid"==='vid');
console.log(true=="true") //value for datatype boolean with value true is 1