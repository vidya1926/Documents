function signUp(fName, email, city, lName, age) {
    console.log("Sign up with ".concat(fName, ", ").concat(email, ",").concat(city, "  "));
}
signUp("Ranjini", "R", "rr@gmail.com", "chennai", 40);
//Default Parameters
function type(password, userName) {
    if (userName === void 0) {
        userName = 'DemosalesManager';
    }
    console.log("Sign in with ".concat(userName, " and ").concat(password));
}
type("crmsfa", "DemoCSR");
