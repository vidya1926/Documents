
let type;

function orderBriyani(){
 
console.log("Type of briyani ordered ");
//action--kitchen--10 sec
setTimeout(() => {
    console.log("Briyaniis getting prepared");
    type="veg"
},5000)
console.log("briyani delivered");

}

const briyaniType=orderBriyani();
console.log("Delivered " +briyaniType+ " was yummy")