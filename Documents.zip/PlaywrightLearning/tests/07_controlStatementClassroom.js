
for(let number=1;number<=10;number++){
if(!(number%2==0)){
    console.log(number);
}
}

let val=1;
let sum=0;

while(val<=10){
    sum=sum+val;    
    val++;
}
console.log(sum);