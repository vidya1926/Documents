
function getBrowserVersion(){
    if(browserName==="chrome"){
        return "119.29.145";
    }else if(browserName==="firefox"){
       return "120.34.124";
    }else{
        return "unsupported browser";
    }    
    }
   let browserName="firefox";
   let version= getBrowserVersion();
   console.log(version);

   function getBrowserOptimized()
    {
        switch(browser){
            case "chrome":
             return browser;
                break;

             case "firefox":
            return browser;
            break;
            default :
            return "unsupported"
            break;
        }
    }

    let browser ="edge";
    let browserOptimized=getBrowserOptimized();
    console.log(browserOptimized);


const sum = (a,b) =>a+b;
console.log(sum(1,2));