

let bhealthy=false;

for(let i=0;i<10;i++){
    if(!bhealthy && i > 2)
    {
        break;
    }
    console.log(i);
}


let isRaining =false;

while(!isRaining){
    console.log("its raining:")
}