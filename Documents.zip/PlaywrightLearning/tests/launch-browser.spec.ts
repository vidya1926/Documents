import { chromium ,test} from "@playwright/test"
test("Launch the browser",async ()=> {

   const browser= await chromium.launch({headless:false});

   const browserContext=await browser.newContext();

    const page= await browserContext.newPage();

    
  await page.goto("http://www.google.com");

    const title=await page.title();
    console.log(title);  
    
    await page.waitForTimeout(5000);


})