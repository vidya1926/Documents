import { chromium, test } from "@playwright/test";

test("To launch a browser", async () => {

const browserInstance = await chromium.launch({ headless: false, channel:
"chrome" });

const browserContext = await browserInstance.newContext();

const page = await browserContext.newPage();
await page. goto ("https://login.salesforce.com/"); // const userName=page.locator ("#username");
 const userName=page.getByLabel ("Username");
const password=page.locator ("#password");
 const submit=page.locator ("#Login");
await userName.fill("vidyar@testleaf.com"); await password. fill ("Force@123");
await submit.click();
 await page.waitForLoadState('load');
const toggleMenu= page. locator (".slds-icon-waffle"); 
await toggleMenu.click();
// await page.waitForLoadState ('load'); 
await page.locator('//button[text()="View All"]').click();

await page.getByRole('link', {name: /Individuals/i}).click();
const individualTitle=await page.title();
console.log(individualTitle);
const lastame="anand";
//page.locator ( [data-refid="recordId"] [title="${lastame}`]);
page. click (`[title=${lastame}]`); 
await page.waitForLoadState ('load'); 
await page. locator ('div[title="Edit"]').click();
await page.getByText('--None--').click();
await page.waitForLoadState ('load'); 

await page.click('a[title="Prof."]');
//await individualSave.click();
});