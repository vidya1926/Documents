const browserVersion= "119.20.124";
var browserName="Chrome"
getBrowserVersion(browserName);
function getBrowserVersion(browserName){
    if(browserName.startsWith("Chrome")){
        let browserVersion="120.20.123";
        console.log("In latest chrome version" +browserVersion);
    }else{
        console.log("In older version");
    }
    console.log(browserVersion);
    }
