
var firstname="vidya";
console.log(typeof firstname);

var companyname="Testleaf";
console.log(typeof companyname);

var mobilenumber=8975729008;
console.log(typeof mobilenumber);

var isAutomation=true;
console.log(typeof isAutomation);

var hasPlaywright;
console.log(typeof hasPlaywright);