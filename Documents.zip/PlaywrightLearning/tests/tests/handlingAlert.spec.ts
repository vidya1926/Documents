
import { test, chromium } from "@playwright/test";

import fs from'fs';
import path from "path";

test.skip("Handle alert", async ({ page, context }) => {


    await page.goto("https://www.leafground.com/alert.xhtml");
    await page.waitForTimeout(5000);

    page.on("dialog", async dialog => {
        console.log(dialog.message());
        dialog.accept();

    })

    await page.click("//span[text()='Show']");


})
test.skip("Handling confirm", async ({ page }) => {

    await page.goto("https://www.leafground.com/alert.xhtml");
    await page.waitForTimeout(5000);


    await page.click("(//span[text()='Show'])[3]");
    await page.waitForTimeout(5000);
    page.on("dialog", async dialog => {
        console.log(dialog.message());

        console.log(dialog.type());
        dialog.dismiss();
    })
    await page.waitForTimeout(5000);

})

test.only('Handling frame', async ({ page }) => {

    await page.goto("https://www.leafground.com/frame.xhtml");
    const frameCount = page.frames().length;
    console.log(frameCount);

    const frameEle = page.frameLocator("(//iframe)[3]");
    const clickEle = frameEle.frameLocator("//iframe").locator("#Click");
    console.log(await clickEle.innerText());
    clickEle.click();
    await page.waitForTimeout(5000);
})


const loginData = JSON.parse(fs.readFileSync(path.join(__dirname,'loginData.json'), 'utf-8'));
for(const credentials of loginData){
test(`Login Test for${credentials.username}`, async({page})=>{
    await page.goto("https://login.salesforce.com/");
    await page.fill("#username", credentials.username)
    await page.fill("#password", credentials.password);
    await page.click("#Login");
})
}