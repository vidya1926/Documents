 
import { expect, test } from "@playwright/test";
import logintestdata from "../../test_data/logintestdata.json";
 
test("Learning data handling", async ({ context, page }) => {
 
     await page.goto("https://login.salesforce.com");
     await page.fill("#username", logintestdata.username);
     await page.fill("#password", logintestdata.password);
     await page.click("#Login");
})