import { expect, request, test } from "@playwright/test";


let sysid: any

test('Create an incident in Servicenow application', async ({ request }) => {

    const url = 'https://dev205797.service-now.com//api/now/table/incident';

    const apiResponse = await request.post(url, {
        headers: {
            "Content-Type": "application/json",
            "Authorization": 'Basic YWRtaW46VGVzdGxlYWZAMTIz'
        },
    });

    const statusCode = apiResponse.status()
    console.log(`Status code is ${statusCode}`)


    const responseBody = await apiResponse.json();
    console.log(responseBody);
    sysid = responseBody.result.sys_id;
    console.log(`Sys id is ${responseBody.result.sys_id}`);
    console.log('--------------------------------------------');

    // const respHeaders = apiResponse.headers();
    // console.log(respHeaders["content-type"]);   
});

test('Get the incident created from Servicenow', async ({ request }) => {

    const url = `https://dev205797.service-now.com//api/now/table/incident/${sysid}`;

    const response = await request.get(url, {
        headers: {
            "Content-Type": "application/json",
            "Authorization": 'Basic YWRtaW46VGVzdGxlYWZAMTIz'
        },
    });
    console.log('--------------------------------------------');
    console.log('Response');
    //generatingToken.body
    const generatingTokenJSON = await response.json();
    console.log(generatingTokenJSON);
    const statuscode = response.status();
    console.log(statuscode);
    console.log('--------------------------------------------');
});

test('Update the incident created from Servicenow', async ({ request }) => {

    const url = `https://dev205797.service-now.com//api/now/table/incident/${sysid}`;

    const response = await request.get(url, {
        headers: {
            "Content-Type": "application/json",
            "Authorization": 'Basic YWRtaW46VGVzdGxlYWZAMTIz'
        },
        data: {
            short_description: "Updating through playwright"
        }
    });
    console.log('--------------------------------------------');
    console.log('Response');
    const statuscode = response.status();
    console.log(statuscode);
    console.log('--------------------------------------------');
});



test('Delete the incident created from Servicenow', async ({ request }) => {

    const url = `https://dev205797.service-now.com//api/now/table/incident/${sysid}`;

    const response = await request.delete(url, {
        headers: {
            "Content-Type": "application/json",
            "Authorization": 'Basic YWRtaW46VGVzdGxlYWZAMTIz'
        },

    });

    console.log('Response');
    const statuscode = response.status();
    console.log(statuscode);


});
