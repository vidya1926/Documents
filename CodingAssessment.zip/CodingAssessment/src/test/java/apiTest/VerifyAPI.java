package apiTest;

import java.util.List;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class VerifyAPI {

	Response response;
	
	
@Given("Enter the Endpoint")
public void enter_the_endpoint() {
   RestAssured.baseURI="http://universities.hipolabs.com/search?country=South+Africa";
}

@When("Using GET Request")
public void using_get_request() {
   response = RestAssured.get();
}

@Then("Verify the StateProvince")
public void verify_the_state_province() {
    JsonPath jsonPath = response.jsonPath();
    List<Object> nameList = jsonPath.getList("name");
    List<Object> provincelist = jsonPath.getList("state-province");
    for (int i = 0; i < nameList.size(); i++) {
    	if(nameList.get(i).equals("University of Witwatersrand")) {
    
    		System.out.println(provincelist.get(i));;
    	}

		
	}
    
    
}
}
