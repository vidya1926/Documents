package hooks;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImpl extends BaseClass {

	@Before
	public void launchApp() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://katalon-demo-cura.herokuapp.com/profile.php#login");
	}

	@After
	public void tearDown() {
		driver.close();
	}
}
