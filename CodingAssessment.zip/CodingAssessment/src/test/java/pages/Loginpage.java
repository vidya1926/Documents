package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Loginpage extends BaseClass{

@Given("Login to the app with the credentials username as {string} and password as {string}")
public EnterDetails login_to_the_app_with_the_credentials_username_as_and_password_as(String username, String pwd) {
  
	driver.findElement(By.id("txt-username")).sendKeys(username);
	driver.findElement(By.id("txt-password")).sendKeys(pwd);
	driver.findElement(By.id("btn-login")).click();
	return new EnterDetails();

	
}


}
