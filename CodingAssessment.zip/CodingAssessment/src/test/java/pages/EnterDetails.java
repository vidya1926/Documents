package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EnterDetails extends BaseClass {

	@Given("Select the Facility")
	public EnterDetails select_the_facility() {

		WebElement dropDown = driver.findElement(By.id("combo_facility"));
		Select sel = new Select(dropDown);
		sel.selectByVisibleText("Hongkong CURA Healthcare Center");
		return this;
	}



@Given("Click on None on Health care program")
public EnterDetails click_on_none_on_health_care_program() {
   driver.findElement(By.id("radio_program_none")).click();
   return this;
}

@Given("Enter the date")
public void enter_the_date() {
   driver.findElement(By.id("txt_visit_date")).sendKeys("10/06/2024");
}

@Given("Enter the description")
public EnterDetails enter_the_description() {
  driver.findElement(By.id("txt_comment")).sendKeys("Booking Appoinment");
  return this;
}

@When("Click on book appoinment")
public BookApp click_on_book_appoinment() {
  driver.findElement(By.id("btn-book-appointment")).click();
  return new BookApp();
}


}
