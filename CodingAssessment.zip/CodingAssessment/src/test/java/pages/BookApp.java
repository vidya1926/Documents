package pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class BookApp extends BaseClass {

	@Then("Verify the facility name as Hongkong CURA Healthcare Center")
	public BookApp verify_the_facility_name_as_hongkong_cura_healthcare_center() {
		String text = driver.findElement(By.id("facility")).getText();
		System.out.println(text);
		Assert.assertTrue(text.equals("Hongkong CURA Healthcare Center"), "The Facility is printed");
		return this;
	}

}
