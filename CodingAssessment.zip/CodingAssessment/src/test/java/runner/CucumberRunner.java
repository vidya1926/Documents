package runner;

import base.BaseClass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="src/test/java/features/BookAppoinment.feature",
glue={"pages","hooks"},
plugin="io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
//publish=true
)

public class CucumberRunner extends AbstractTestNGCucumberTests{
  
	
}
