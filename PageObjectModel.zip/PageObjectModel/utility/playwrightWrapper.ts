import {Page} from '@playwright/test'

export abstract class PlaywrightWrapper{
   
   
    page :Page  //instance property

    constructor(page:Page){
        this.page=page
    }

   async typeAndEnter(locatValue:string,data:string){
    
        await this.page.locator(locatValue).fill(data)
        await this.page.focus(locatValue)
        await this.page.keyboard.press("Enter")
   }
}