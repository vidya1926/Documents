import { Page,Locator } from '@playwright/test';
import { PlaywrightWrapper } from '../utility/playwrightWrapper';
import fs from 'fs'

export class SFLogin {

     lppage:Page
     userNameField:Locator
     passwordField:Locator

    constructor(page:Page){
    this.lppage=page
    this.userNameField=this.lppage.locator("#username")
    this.passwordField=this.lppage.locator("#password")
    }

    async loadUrl(url:string){
            await this.lppage.goto(url)
    }
    async doLogin(username:string,password:string){    
        await this.userNameField.fill(username)
        await this.passwordField.fill(password)
        await this.lppage.locator("#Login").click();
   }
}

// const lp=new SFLogin()  -


// functionName()