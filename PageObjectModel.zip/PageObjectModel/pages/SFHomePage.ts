import { Page, Locator } from "@playwright/test";
import { SFLogin } from "./SalesForceLogin";

export class SFHomePage extends SFLogin {
    appLauncher: Locator
    viewAll: Locator
    searchmodule: Locator
    moduleName: Locator
    // modName:string
    constructor(page: Page) {
        super(page) //brings the reference of parent and give the access to child
        
    }

    async clickAppLauncher(): Promise<string> {      
        await this.page.waitForLoadState('load')
        const title = await this.page.title()
        await this.page.locator(".slds-icon-waffle").click();
        return title;
    }

    async clickViewAll() {
        await this.page.locator(`button[aria-label="View All Applications"]`).click();
    }

    async searchModule(data: string) {
        await this.page.waitForLoadState('load')
        await this.page.getByPlaceholder("Search apps or items...").fill(data)
    }

    async clickLeadModule() {
        //  await this.moduleName(Lead).click();
        await this.page.waitForTimeout(4000)
        await this.page.locator(`//mark[text()='Leads']`).click();

    }

    async clickAccountModule() {
        //  await this.moduleName(Lead).click();
        await this.page.locator(`//mark[text()='Accounts']`).click();

    }


}