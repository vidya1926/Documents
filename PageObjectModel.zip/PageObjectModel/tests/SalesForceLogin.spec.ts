import test from "@playwright/test";
import { SFLogin } from "../pages/SalesForceLogin";
import { SFHomePage } from "../pages/SFHomePage";



test(`SalesForce Login with valid data`, async ({page}) => {

  const lp=new SFLogin(page)
  await lp.loadUrl("https:login.salesforce.com")
 await lp.doLogin("vidyar@testleaf.com","Sales@123")

//  const hp=new SFHomePage(page)
// await hp.appLauncher()
    
})